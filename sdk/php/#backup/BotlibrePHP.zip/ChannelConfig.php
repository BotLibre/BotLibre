<?php
class ChannelConfig {

    
}
?>