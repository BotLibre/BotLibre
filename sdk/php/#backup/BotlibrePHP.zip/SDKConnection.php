<?php
//Include required classes.
require_once "Credentials.php";
require_once('UserConfig.php');
require_once('Config.php');
require_once('ChatConfig.php');
require_once('ChatResponse.php');
require_once('DomainConfig.php');
require_once('ForumPostConfig.php');
class SDKConnection
{
    protected static $types = array("Bots", "Forums", "Graphics", "Live Chat", "Domains", "Scripts", "IssueTracker");
    protected static $channelTypes = array("ChatRoom","OneOnOne");
	protected static $accessModes = array("Everyone", "Users", "Members", "Administrators");
	protected static $mediaAccessModes = array ("Everyone", "Users", "Members", "Administrators", "Disabled");
	protected static $learningModes = array("Disabled", "Administrators", "Users", "Everyone");
	protected static $correctionModes = array("Disabled", "Administrators", "Users", "Everyone");
    protected static $botModes = array("ListenOnly", "AnswerOnly", "AnswerAndListen");
	protected String $url;
    protected ?UserConfig $user;
	protected ?DomainConfig $domain;
    protected Credentials $credentials;
    protected bool $debug = false;

	protected SDKException $exception;


    /**
     * Return the name of the default user image.
     */
    function defaultUserImage()
    {
        return "images/user-thumb.jpg";
    }
    /**
	 * Create an SDK connection with the credentials.
	 * Use the Credentials subclass specific to your server.
	 */
	public function __construct(Credentials $credentials) {
		$this->credentials = $credentials;
		$this->url = $credentials->url;
	}
    /**
     * Validate the user credentials (password, or token).
     * The user details are returned (with a connection token, password removed).
     * The user credentials are soted in the connection, and used on subsequent calls.
     * An SDKException is thrown if the connect failed.
     */
    public function connect(UserConfig $config) : ?UserConfig{
        $config->addCredentials($this);
        $xml = $this->POST($this->url . "/check-user", $config->toXML());
        if($xml == null) {
            $this->user == null;
            return null;
        }
		try {
			$user = new UserConfig();
			$user->parseXML($xml);
			$this->user = $user;
		} catch (Exception $exception) {
			echo "Exception: " . $exception->getMessage() . "\n";
		}
        
        return $this->user;
    }

	/**
	 * Execute the custom API.
	 */
    public function custom(String $api, Config $config, Config $result) : ?Config { //Need Testing
        $config->addCredentials($this);
        $xml = $this->POST($this->url . "/" . $api , $config->toXML());
        if($xml == null) {
            return null;
        }
        try {
			$result->parseXML($xml);
		} catch (Exception $exception) {

			echo "Error: " + $exception->getMessage();
		}
        return $result;
    }

    /**
	 * Connect to the live chat channel and return a LiveChatConnection.
	 * A LiveChatConnection is separate from an SDKConnection and uses web sockets for
	 * asynchronous communication.
	 * The listener will be notified of all messages.
	 */
	// public function openLiveChat(ChannelConfig $channel, LiveChatListener $listener) : LiveChatConnection {
	// 	LiveChatConnection $connection = new LiveChatConnection($this->credentials, $listener);
	// 	$connection->connect($channel, $this->user);
	// 	return $connection;
	// }
	
	/**
	 * Connect to the domain.
	 * A domain is an isolated content space.
	 * Any browse or query request will be specific to the domain's content.
	 */	
	// public function connect(DomainConfig $config) : DomainConfig {
	// 	$this->domain = fetch(config);
	// 	return $this->domain;
	// }
	
	/**
	 * Disconnect from the connection.
	 * An SDKConnection does not keep a live connection, but this resets its connected user and domain.
	 */	
	public function disconnect() {
		$this->user = null;
		$this->domain = null;
	}

	/**
	 * Process the bot chat message and return the bot's response.
	 * The ChatConfig should contain the conversation id if part of a conversation.
	 * If a new conversation the conversation id i returned in the response.
	 */
	public function chat(ChatConfig $config) : ?ChatResponse { //Tested
		$config->addCredentials($this);
		$xml = $this->POST($this->url . "/post-chat", $config->toXML());
		if($xml == null) {
			return null;
		}
		try {
			$response = new ChatResponse();
			$response->parseXML($xml);
			return $response;
		} catch (Exception $exception) {
			echo "Error: " + $exception;
		}
	}

	
    /**
	 * Fetch the user details.
	 */	
	public function fetchUserDetails(UserConfig $config) : ?UserConfig { //Need Testing
		$config->addCredentials($this);
		$xml = $this->POST($this->url . "/view-user", $config->toXML());
        if($xml == null) {
            return null;
        }
		try {
			$user = new UserConfig();
			$user->parseXML($xml);
			return $user;
		}catch(Exception $exception) {
			echo "Error: " . $exception->getMessage();
		}
	}

	/**
	 * Fetch the URL for the image from the server.
	 */	
	// public function fetchImage(String $image) : URL {
	// 	try {
	// 		return new URL("http://" . $this->credentials->host + $this->credentials->app . "/" + $image);
	// 	} catch (Exception $exception) {
	// 		echo "Error: " . $exception->getMessage();
	// 	}
	// }

	/**
	 * Fetch the forum post details for the forum post id.
	 */	
	public function fetchForumPost(ForumPostConfig $config) : ?ForumPostConfig {
		$config->addCredentials($this);
		$xml = $this->POST($this->url . "/check-forum-post", $config->toXML());
		if ($xml == null) {
			return null;
		}
		try {
			$post = new ForumPostConfig();
			$post->parseXML($xml);
			return $post;
		} catch (Exception $exception) {
			echo "Error: " . $exception->getMessage();
		}
	}

	/**
	 * Return the current connected user.
	 */
	public function getUser() : UserConfig {
		return $this->user;
	}

	/**
	 * Set the current connected user.
	 * connect() should be used to validate and connect a user.
	 */
	public function setUser(UserConfig $user) : void {
		$this->user = $user;
	}

	/**
	 * Return the current domain.
	 * A domain is an isolated content space.
	 */
	public function getDomain() : ?DomainConfig {
		if(isset($this->domain)) {
			return $this->domain;
		}
		return null;
	}

	/**
	 * Set the current domain.
	 * A domain is an isolated content space.
	 * connect() should be used to validate and connect a domain.
	 */
	public function setDomain(DomainConfig $domain) : void {
		$this->domain = $domain;
	}

    /**
	 * Return the current application credentials.
	 */
	public function getCredentials() : ?Credentials{
		if($this->credentials == null) {
			var_dump($this->credentials);
			echo "(SDKConnection) This credentials is null.";
			return null;
		}
		return $this->credentials;
	}

	/**
	 * Set the application credentials.
	 */
	public function setCredentials(Credentials $credentials) : void {
		$this->credentials = $credentials;
		$this->url = $credentials->url;
	}

	/**
	 * Return is debugging has been enabled.
	 */
	public function isDebug() : bool {
		return $this->debug;
	}

	/**
	 * Enable debugging, debug messages will be logged to System.out.
	 */
	public function setDebug(bool $debug) : void {
		$this->debug = $debug;
	}
    // public Element parse(String xml) {
	// 	if (this.debug) {
	// 		System.out.println(xml);
	// 	}
	// 	Document dom = null;
	// 	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	// 	try {
	// 		DocumentBuilder builder = factory.newDocumentBuilder();
	// 		InputSource source = new InputSource();
	// 		source.setCharacterStream(new StringReader(xml));
	// 		dom = builder.parse(source);
	// 		return dom.getDocumentElement();
	// 	} catch (Exception exception) {
	// 		if (this.debug) {
	// 			exception.printStackTrace();
	// 		}
	// 		this.exception = new SDKException(exception.getMessage(), exception);
	// 		throw this.exception;
	// 	}
	// }

	public function POST(String $url, String $xml) : String{
		if($this->debug) {
			echo "<br>-----------DEBUG-----------<br>";
			echo $url . "<br>";
			echo htmlentities( $xml);
			echo "<br>-----------DEBUG-----------<br>";
		}
		$ch = curl_init();
		$xmlData = simplexml_load_string($xml) or die("Error: Cannot create object");
		if($this->debug) {
			echo "<br>-----------DEBUG-----------<br>";
			print_r($xmlData);
			echo "<br>-----------DEBUG-----------<br>";
		}
		
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml); //It needs the actual xml text not the object
		// The result of simplexml_load_string($xml) passing a string xml will return a data object xml.
		// curl_setopt just need a string text of the xml.
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$headers = [
			'Content-Type: application/xml',
			'Accept: application/xml'
		];

		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$response = curl_exec($ch);
		if ($e = curl_error($ch)) {
			echo $e;
		} else {
			if($this->debug){
				$result = simplexml_load_string($response);
				echo "<br>-----------DEBUG-----------<br>";
				print_r($response);
				echo "<br>";
				print_r($result);
				echo "<br>-----------DEBUG-----------<br>";
			}
		}
		curl_close($ch);
		return $response;
	}
}
?>