<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>BotLibre API</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
	<div class="container">
		<form action="Main.php" method="get">
			<label for="api">Select API:</label>
			<select id="api" name="api">
				<option value="">Choose a service</option>
				<option value="connect">Connecting User</option>
				<option value="chat">Sending a message</option>
			</select>
			<br><br>
			<input type="submit" value="TEST">

			<?php
			if (isset($_GET["api"])) {
				echo "API : " . $_GET["api"];
			} else {
				echo "Nothing is selected.";
			}
			?>

		</form>
	</div>
	<?php
	require_once('SDKConnection.php');
	require_once('BotlibreCredentails.php');

	class Main
	{

		public static ?bool $DEBUG = true;
		public static ?bool $ADULT = false;

		/**
		 * Enter your application ID here.
		 * You can get an application ID from any of the services websites (BOT libre, FORUMS libre, LIVE CHAT libre, Paphus Live Chat)
		 */
		public string $applicationId = "986530966192349057";
		public string $twitterAppId = "6022406562833792899";
		public string $paphusAppId = "1444710791353231612";
		public string $forumsAppId = "1401036148793048377";
		public string $livechatAppId = "1401036148793048377";

		/**
		 * Configure your connection credentials here.
		 * Choose which service provider you wish to connect to.
		 */
		public static ?SDKConnection $connection = null;

		public static ?string $domainId = null;
		public static ?DomainConfig $domain;
		public static string $defaultType = "Bots";
		public static bool $showAds = true;

		public function __construct()
		{
			Main::$connection = new SDKConnection(new BotlibreCredentails($this->applicationId));
			if (Main::$domainId != null) {
				Main::$domain = new DomainConfig();
				Main::$domain->id = $this->domainId;
				Main::$connection->setDomain(Main::$domain);
			}
			if (Main::$DEBUG) {
				echo "<br>-----------DEBUG-----------<br>";
				var_dump(Main::$connection);
				Main::$showAds = false;
				Main::$connection->setDebug(true);
				echo "<br>-----------DEBUG-----------<br>";
			}

		}
		public static ?string $WEBSITE = "http://www.botlibre.com";
		public static ?string $WEBSITEHTTPS = "https://www.botlibre.com";
		public static ?string $SERVER = "botlibre.com";
		/**
		 * If you are building a single instance app, then you can set the instance id or name here,
		 * and use this activity to launch it.
		 */
		public static ?string $launchInstanceId = ""; // i.e. "171"
		public static ?string $launchInstanceName = ""; // i.e. "Help Bot"
	


		public function connectUserAccount(): UserConfig
		{
			//TODO: Setup user
			echo "<h3>TEST: Connecting to the user...</h3>";
			$userConfig = new UserConfig();
			$userConfig->application = "7369571872937606859";
			$userConfig->user = "Account_test";
			$userConfig->password = "password123";
			$userConfig = Main::$connection->connect($userConfig);
			return $userConfig;
		}

		public function sendChatMessage(): ?ChatResponse
		{
			//TODO: Setup message
			$config = new ChatConfig();
			$config->message = "How are you?";
			$config->application = "7369571872937606859";
			$config->instance = "165";
			$response = Main::$connection->chat($config);
			return $response;
		}
	}
	?>
	<fieldset>
		<legend>Logs</legend>
		<?php
		//TODO:
		$main = new Main();

		if (isset($_GET["api"])) {
			echo "<strong>Selected: " . $_GET["api"] . "</strong>\n";
			switch ($_GET["api"]) {
				case "connect";
					$userConfig = $main->connectUserAccount();
					break;
				case "chat":
					$userConfig = $main->connectUserAccount();
					echo "<br><br><br>";
					echo "<h3>TEST: Sending a message...</h3>";
					$response = $main->sendChatMessage();
					break;
			}
		}
		?>

	</fieldset>
	<div id="box">
		<h4>Account Details</h4>
		<?php
		if (isset($userConfig)) {
			echo "User: " . $userConfig->user . "<br>";
			echo "Joined: " . $userConfig->joined . "<br>";
			echo "Connects: " . $userConfig->connects . "<br>";
			echo "Name: " . $userConfig->name . "<br>";
		} else {
			echo "There is no data to show yet.";
		}
		?>
	</div>
</body>

</html>